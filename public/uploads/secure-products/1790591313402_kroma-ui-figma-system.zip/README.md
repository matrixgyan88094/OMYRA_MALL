# Kroma Design System
Figma Auto Layout 5.0