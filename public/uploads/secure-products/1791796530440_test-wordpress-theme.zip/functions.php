<?php // WordPress Theme Functions 
add_action("wp_enqueue_scripts", "my_scripts");